# MathSMA AI 🧮

Aplikasi web interaktif sederhana untuk membantu siswa SMA menyelesaikan dan menganalisis soal-soal Matematika.

## 🚀 Fitur Utama
- **Analisis Soal**: Asisten pengerjaan soal matematika SMA step-by-step.
- **Kalkulator Persamaan Kuadrat**: Menghitung diskriminan ($D$) dan akar-akar ($x_1, x_2$) secara instan.
- **Quick Formula Picker**: Referensi cepat rumus-rumus penting SMA (Kalkulus, Trigonometri, Aritmatika).
- **Desain Modern & Responsive**: Menggunakan Tailwind CSS & FontAwesome.

## 📦 Panduan Deploy ke Vercel

1. **Upload ke GitHub**:
   - Buat repositori baru di GitHub.
   - Upload seluruh isi folder project ini (atau push melalui Git).

2. **Deploy di Vercel**:
   - Buka [Vercel](https://vercel.com) dan login dengan akun GitHub kamu.
   - Klik **Add New...** -> **Project**.
   - Import repositori `math-sma` dari akun GitHub kamu.
   - Klik **Deploy**.

3. **Pasang Custom Domain (Opsional)**:
   - Masuk ke dashboard Vercel -> **Settings** -> **Domains**.
   - Tambahkan domain kustom kamu dan sesuaikan **A Record** (`76.76.21.21`) atau **CNAME Record** (`cname.vercel-dns.com`) di penyedia domain milikmu.

---
*Dibuat untuk Pelajar SMA Indonesia.*
